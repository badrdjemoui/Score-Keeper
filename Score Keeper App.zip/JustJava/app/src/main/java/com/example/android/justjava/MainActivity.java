package com.example.android.justjava;

import android.os.Bundle;

import android.view.View;

import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

/*****************************global variable***********************************/

    int quantity1 = 0;
    int quantity2 = 0;


/************************************onCreate**********************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
/*******************************************reset************************************/
    public void reset(View view) {
        quantity1 = 0;
        quantity2 = 0;
        displayQuantity1(quantity1);
        displayQuantity2(quantity2);
    }


    /**************************************increment1***********************************/
    public void increment1(View view) {
        if (quantity1 == 100) {
            return;
        }
        quantity1 = quantity1 + 1;
        displayQuantity1(quantity1);
    }

    /**************************************decrement1***********************************/
    public void decrement1(View view) {
        if (quantity1 == 0) {
            return;
        }
        quantity1 = quantity1 - 1;
        displayQuantity1(quantity1);
    }
    /****************************************displayQuantity1********************************************/

    private void displayQuantity1(int goal) {
        TextView quantityTextView = (TextView) findViewById(
                R.id.score1);
        quantityTextView.setText("" + goal);
    }

    /**************************************increment2********************************************************/



    public void increment2(View view) {
        if (quantity2 == 100) {
            return;
        }
        quantity2 = quantity2 + 1;
        displayQuantity2(quantity2);
    }
/**************************************decrement2************************************************/

    public void decrement2(View view) {
        if (quantity2 == 0) {
            return;
        }
        quantity2 = quantity2 - 1;
        displayQuantity2(quantity2);
    }
/********************************************displayQuantity2*************************************/
    private void displayQuantity2(int numberOfCoffees) {
        TextView quantityTextView = (TextView) findViewById(
                R.id.score2);
        quantityTextView.setText("" + numberOfCoffees);
    }
}